Project Name: Solar powered fan
Project Version: 540e8743
Project Url: https://www.flux.ai/wawakowero11/solar-powered-fan

Project Description:
Welcome to your new project. Imagine what you can build here.

Project Properties:

width:


size:
10 10  2


